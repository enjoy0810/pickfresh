export * from './create-product.input';
export * from './update-product.input';
export * from './product-query.input';
export * from './delete-product.input';